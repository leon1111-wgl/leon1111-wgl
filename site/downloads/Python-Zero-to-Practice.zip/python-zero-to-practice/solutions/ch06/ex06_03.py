# 第 06_03 题 排除缺测值
# [-1, 30, 0, 45, -1] 中 -1 表示缺测，0 有效。输出有效条数 3 与总量 75，各一行。
# 预期程序输出：
# 3
# 75

count = 0
total = 0
for value in [-1, 30, 0, 45, -1]:
    if value == -1:
        continue
    count += 1
    total += value
print(count)
print(total)
