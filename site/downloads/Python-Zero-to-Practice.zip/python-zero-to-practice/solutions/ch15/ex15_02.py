# 第 15_02 题 按批产生列表
# 实现 batches(values,size)，size 是整数，<=0 时在消费时抛 ValueError；每次 yield 一个至多 size 项的切片，保留最后不足一批的数据。打印对 [1,2,3,4,5] 与 2 的结果。
# 预期程序输出：
# [[1, 2], [3, 4], [5]]

def batches(values, size):
    if size <= 0:
        raise ValueError("size 必须为正数")
    for start in range(0, len(values), size):
        yield values[start:start + size]

print(list(batches([1, 2, 3, 4, 5], 2)))
