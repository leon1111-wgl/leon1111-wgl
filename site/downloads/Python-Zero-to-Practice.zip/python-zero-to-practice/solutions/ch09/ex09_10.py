# 第 09_10 题 AI / Agent：把剩余预算逐步传下去
# 实现 remaining_budget(remaining, used)，两个输入保证为非负整数，返回扣减后的余额，最低为 0；函数不得打印或依赖全局余额。先设 budget=60，接收扣 15 的结果并打印；再接收扣 50 的结果并打印。
# 预期程序输出：
# 45
# 0

def remaining_budget(remaining, used):
    result = remaining - used
    if result < 0:
        return 0
    return result

budget = 60
budget = remaining_budget(budget, 15)
print(budget)
budget = remaining_budget(budget, 50)
print(budget)
